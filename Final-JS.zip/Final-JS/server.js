const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const app = express();

app.use(cors());
app.use(express.json());

// Conexión a la base de datos
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'crud_db'
});

db.connect(err => {
  if (err) throw err;
  console.log('Conectado a la base de datos');
});

// Ruta GET: obtener todos los registros
app.get('/items', (req, res) => {
  db.query('SELECT * FROM items', (err, result) => {
    if (err) throw err;
    res.json(result);
  });
});

// Ruta POST: agregar un nuevo registro
app.post('/items', (req, res) => {
  const { name } = req.body;
  db.query('INSERT INTO items (name) VALUES (?)', [name], (err, result) => {
    if (err) throw err;
    res.json({ status: 'Item agregado' });
  });
});

// Ruta PUT: actualizar un registro
app.put('/items/:id', (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  db.query('UPDATE items SET name = ? WHERE id = ?', [name, id], (err, result) => {
    if (err) throw err;
    res.json({ status: 'Item actualizado' });
  });
});

// Ruta DELETE: eliminar un registro
app.delete('/items/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM items WHERE id = ?', [id], (err, result) => {
    if (err) throw err;
    res.json({ status: 'Item eliminado' });
  });
});

app.listen(5000, () => {
  console.log('Servidor en puerto 5000');
});
